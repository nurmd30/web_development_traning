<html>

<head>
	<style>
		.one, .two, .three {
			width: 33%;
			display: table-cell;
		}
		.row {
			width: 100%;
			display: table;
			background-color: lightgreen;
			text-align: center;
		}
		.index {
			font-weight: bold;
			background-color: lightblue;
		}
		.body {
			font-family: Verdana;
		}
	</style>
</head>

<body>

<div class="row index">
	<div class="one">A</div>
	<div class="two">B</div>
	<div class="three">C</div>
</div>
<div class="row">
	<div class="one">A</div>
	<div class="two">B</div>
	<div class="three">C</div>
</div>

</body>
</html>