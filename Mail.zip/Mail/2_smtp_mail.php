<?php
/*
	JUST INCLUDE THIS FUNCTION IN YOUR PROJECT / DON'T EDIT ANYTHING HERE
*/

function smtpMail($mailConfig, $mailDetails, $mailReceiver)
{
	require_once 'smtpMail/swift_required.php';

	# AUTHENTICATION
	$transport = Swift_SmtpTransport::newInstance($mailConfig['host'], $mailConfig['port'])
	  ->setUsername($mailConfig['email'])
	  ->setPassword($mailConfig['pass'])
	;
	
	# CONNECTION
	$mailer = Swift_Mailer::newInstance($transport);

	# PREPARING THE MAIL
	$fullMessage = Swift_Message::newInstance($mailDetails['title'])
	  ->setFrom(array($mailConfig['email'] => $mailConfig['name']))
	  ->setTo($mailReceiver)
	  ->setContentType($mailConfig['type'])
	  ->setBody($mailDetails['body']);
	  
	# SENDING THE MAIL
	$result = $mailer->send($fullMessage);
}

/*
	YOU HAVE TO EDIT THE BELOW LINES ONLY
*/

	# CONFIGURE THE MAIL SETTINGS / CHECKING FROM YOUR cPANEL
	$mailConfig['host'] = "mail.nirjhor.net";
	$mailConfig['port'] = 26;
	$mailConfig['name'] = "Nirjhor Anjum";
	$mailConfig['email'] = "pnt@nirjhor.net";
	$mailConfig['pass'] = "iram786";
	$mailConfig['type'] = "text/plain"; // "text/html";
	
	# PREPARE YOUR MAIL
	$mailDetails['title'] = "Signup Success! Your ... Username & Password";
	$mailDetails['body'] = "Dear User,".PHP_EOL.PHP_EOL."Welcome to ..., the ... for you.".PHP_EOL.PHP_EOL."Here goes your ... Details:.".PHP_EOL.PHP_EOL."Login Link: " . "" .PHP_EOL. "Username: " . "PHP User Variable" .PHP_EOL. "Password: " . "PHP Pass Variable" . PHP_EOL.PHP_EOL. "Please remember this user login details for further use." .PHP_EOL.PHP_EOL. "Please do not share your Username or Password with anyone else." .PHP_EOL.PHP_EOL. "For any kind of issue related to ... please mail at: ... ." .PHP_EOL.PHP_EOL. "... ." .PHP_EOL. "... .";
	
	# PREPARE YOUR RECEIVERS
	$mailReceiver = array('marahman.dg@gmail.com', 'alishahriyar@gmail.com', 'motaleb@seefashion.tk');
	
	# SEND THE MAIL
	smtpMail($mailConfig, $mailDetails, $mailReceiver);

?>