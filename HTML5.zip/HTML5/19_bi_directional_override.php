<p>
	<bdo dir="rtl">My Name is Nirjhor Anjum</bdo>
</p>

<p>
	<bdo dir="ltr">My Name is Nirjhor Anjum</bdo>
</p>