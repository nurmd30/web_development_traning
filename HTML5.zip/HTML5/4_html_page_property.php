<!DOCTYPE html>
<html>
<head>

<!-- TITLE OF A PAGE -->
<title>Nirjhor.Net | Nirjhor's Website</title>

<!-- CHARACTER SET / Character Encoding for the HTML Document -->
<meta charset="UTF-8">

<!-- KEYWORDS - SEARCHING ON WHICH THE SITE WILL BE VISIBLE ON SEARCH ENGINES -->
<meta name="keywords" content="Nirjhor, Anjum, Personal, Website">

<!-- DESCRIPTION THAT WILL GO TO GOOGLE SEARCH ENGINE -->
<meta name="description" content="Welcome to the Website of Nirjhor Anjum. It is the Personal Website of Nirjhor!">

<!-- AUTHOR NAME OF THIS PAGE -->
<meta name="author" content="Nirjhor Anjum">

<!-- THIS WILL RELOAD THE PAGE AFTER EACH 30 SECOND INTERVAL -->
<meta http-equiv="refresh" content="30">

</head>

<body>
	<!-- CODE OF YOUR HTML PAGE -->
</body>

</html>