Welcome to the Registration Form: <br><br>
<form name="input" action="" method="post">

	<!-- RADIO BUTTON -->
	Gender:
	<input type="radio" name="gender" value="male">Male
	<input type="radio" name="gender" value="female">Female<br>
		<br>
		
	<!-- CHECK/TICK BUTTON -->
	Choose Product: 
	<input type="checkbox" name="item1" value="mobile">Mobile
	<input type="checkbox" name="item2" value="laptop">Laptop<br>
		<br>
	
	<!-- SELECT AND OPTIONS - BUTTON -->
	Country: 
	<select name="country">
		<option value="BD">BD</option>
		<option value="Not BD">Not BD</option>
	</select>
		<br>
		<br>
	
	<!-- TEXT TYPE INPUT FIELD -->
	Username: <input type="text" name="userNAME" placeholder="Put your Username" required ><br><br>

	<!-- PASSWORD TYPE INPUT FIELD -->
	Password: <input type="password" name="passWORD" required ><br><br>

	<!-- EMAIL TYPE INPUT FIELD -->
	Email Address: <input type="email" name="emailADDRESS"><br><br>

	<!-- NUMERIC TYPE INPUT FIELD -->
	Zip Code: <input type="number" name="zipCODE" min="1" max="4"><br><br>
	
	<!-- DATE TYPE INPUT FIELD -->
	Date of Birth: <input type="date" name="dateofBIRTH" min="2000-11-12" max="2014-11-30"><br><br>
	
	<!-- COLOR TYPE INPUT FIELD -->
	Color you Like: <input type="color" name="myCOLOR" value="#ff0000"><br><br>
	
	<br>
	<input type="submit" value="Press Enter" name="submit" />
	
</form>