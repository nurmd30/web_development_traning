<b>This is an EXAMPLE</b> 							<br /><br /><!-- 	Defines bold text	-->
 
<u>This is an EXAMPLE</u>							<br /><br /><!-- 	Defines underlined text	-->

<i>This is an EXAMPLE</i>							<br /><br /><!-- 	Defines a part of text in an alternate voice or mood	-->

<small>This is an EXAMPLE</small>					<br /><br /><!-- 	Defines smaller text	-->

<strong>This is an EXAMPLE</strong>					<br /><br /><!-- 	Defines important text	-->

<sub>This is an EXAMPLE<sub>						<br /><br /><!-- 	Defines subscripted text	-->

<sup>This is an EXAMPLE</sup>						<br /><br /><!-- 	Defines superscripted text	-->

<del>This is an EXAMPLE</del>						<br /><br /><!-- 	Defines deleted text	-->

<mark>This is an EXAMPLE</mark>						<br /><br /><!-- 	Defines marked/highlighted text	-->

<code>This is an EXAMPLE</code>						<br /><br /><!-- 	Defines computer code text	-->

<blockquote>This is an EXAMPLE</blockquote>			<br /><br /><!-- 	Defines a section that is quoted from another source	-->

<q>This is an EXAMPLE</q>							<br /><br /><!-- 	Defines an in-line (short) quotation	-->