<html>

<body>

	<img src="files/mylogo.png" alt="MY IMAGE" width="200" height="100">

</body>

</html>
