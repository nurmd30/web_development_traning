<pre>
Text in a pre element
is displayed in a fixed-width
font, and it preserves
both      spaces and
line breaks

Here is a C Programming Code Below:

  #include <stdio.h>
  
  int main()
  {
  printf("Hello world\n");
  return 0;
  }

</pre>