
<!-- PROGRESS Tag helps us to show the Progress of anything as a Level -->
<progress value="25" max="100"> </progress>

<br /><br />

<!-- METER Tag helps us to show the Meter of anything as a Level -->
<meter value="2.5" min="0" max="10">2 out of 10</meter><br>
<meter value="0.75">50%</meter>

<br /><br />

<!-- OUTPUT Tag is just used to identify that region where Output of any Action is shown -->
<output name="result"></output>