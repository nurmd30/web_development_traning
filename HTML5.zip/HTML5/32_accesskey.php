<!DOCTYPE html>
<html>
<body>

<a href="http://nirjhor.net" accesskey="n">Nirjhor.Net</a><br>
<a href="http://www.piit.us" accesskey="p">PIIT.US</a>

<ul>
	<li>IE, Chrome, Safari, Opera 15+: [ALT] + <em>accesskey</em></li>
	<li>Opera prior version 15: [SHIFT] [ESC] + <em>accesskey</em></li>
	<li>Firefox: [ALT] [SHIFT] + <em>accesskey</em></li>
</ul>

</body>
</html>
