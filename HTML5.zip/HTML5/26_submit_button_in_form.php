<!DOCTYPE html>
<html>
<body>

<form>

<button type="submit" name='submit' form="" formmethod="post" formaction="edit.php" formenctype="" formtarget="_blank" value="CLICKED" onclick="" >Enter</button>

</form>

</body>
</html>

<!-- 
FormEncType:
	application/x-www-form-urlencoded
	multipart/form-data
	text/plain
	
FormTarget:
	_self
	_blank
	
FormMethod:
	get
	post
-->