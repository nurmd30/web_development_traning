<video width="320" height="240" controls >

	<source src="files/baby.mp4" type="video/mp4">
  
	Your Browser is not Supporting This Feature
	
</video>