<!DOCTYPE html>
<html>

	<head>
		<style>
			<!-- YOUR CSS CODE -->
			<link rel="stylesheet" type="text/css" href="my_css_file_name.css" />
		</style>
		
		<script>
			<!-- YOUR JAVASCRIPT CODE -->
		</script>
	</head>

	<body>
		
	</body>
	
</html>

