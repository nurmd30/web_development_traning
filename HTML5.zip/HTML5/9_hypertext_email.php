<html>

<body>

	<a href="http://www.piit.us/" target="_self">Visit PIIT</a>
<br />
	<a href="http://www.piit.us/" target="_blank">Visit PIIT on a New Tab</a>
<br />
	<a href="mailto:anjum@nirjhor.net">anjum@nirjhor.net</a>
	
</body>

</html>