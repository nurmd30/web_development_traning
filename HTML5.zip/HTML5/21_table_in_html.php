<table style="width:300px">
	<caption>Point Table</caption>
	<tfoot>
	<tr>
		<td>Footer 1</td>
		<td>Nirjhor</td> 
		<td>50</td>
	</tr>
	</tfoot>
	<thead>
	<tr>
		<td>Head 1</td>
		<td>Nirjhor</td> 
		<td>50</td>
	</tr>
	</thead>
	<tbody>
	<tr>
		<td>Body 1</td>
		<td>Nirjhor</td> 
		<td>50</td>
	</tr>
	</tbody>
</table>


<table border="1" style="width:100%;border-collapse:collapse;text-align:center;">
	<caption>Point Table</caption>
	<thead style="background:gray;color:white;text-align:center;border-color:white;">
		<tr>
			<td>Last Name</td>
			<td>First Name</td>
			<td>Point</td>
		</tr>
	</thead>
	<tbody>
		<tr>
			<td>Ishak</td>
			<td>Abdullah</td> 
			<td>50</td>
		</tr>
		<tr>
			<td>Anjum</td>
			<td>Nirjhor</td> 
			<td>90</td>
		</tr>
	</tbody>
	<tfoot>
	<tr>
		<td></td>
		<td></td> 
		<td>140</td>
	</tr>
	</tfoot>
</table>