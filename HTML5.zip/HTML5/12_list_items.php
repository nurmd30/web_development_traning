<html>
	<body>

	<!-- Description List -->
	<dl>
		<dt>Windows</dt> <!-- Define Terms -->
			<dd>- Windows is an Operating System developed by Microsoft Corporation.</dd> <!-- Define Details -->
		<dt>Ubuntu</dt>
			<dd>- Ubuntu is a type of Linux Operating System!</dd>
	</dl>

	<!-- Ordered List -->
	<ol>
		<li>Nirjhor</li> <!-- List Item -->
		<li>Anjum</li>
		<li>Durjoy</li>
		<li>Mamun</li>
		<li>Hamid</li>
	</ol>

	<!-- Unordered List -->
	<ul>
		<li>HTML</li>
		<li>CSS</li>
		<li>JavaScript</li>
		<li>jQuery Basics</li>
		<li>AJAX Basics</li>
		<li>PHP 5.6</li>
		<li>SQL/MySQL</li>
		<li>Web Project</li>
	</ul>

	</body>
</html>