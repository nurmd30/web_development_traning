<!DOCTYPE html>
<html>

	<head>
		<!-- Your CSS and JAVASCRIPT codes will be Here -->
	</head>

	<body>
		<!-- Your HTML + PHP + MYSQL Code (Call CSS and JAVASCRIPT from Here) -->
	</body>
	
</html>