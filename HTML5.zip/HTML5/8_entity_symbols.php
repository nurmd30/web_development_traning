<!-- ENTETIES -->
&reg; = Registered Trademark
<br /><br />
&copy; = Copy Right
<br /><br />
&euro; = Euro
<br /><br />
&nbsp; = Single Space
<br /><br />
&cent; = Cent
<br /><br />
&pound; = Pound
<br /><br />

<!-- Symbols -->
&copy; = Copy
<br /><br />
&sum; = Summation
<br /><br />
&isin; = Element Of
<br /><br />
&notin; = Not Element Of
<br /><br />
&trade; = Trade Mark
<br /><br />
&reg; = Register
<br /><br />
&empty; = Empty
<br /><br />
&part; = Differential