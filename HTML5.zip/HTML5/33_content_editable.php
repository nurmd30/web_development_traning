<!-- THE CONTENT WILL BE EDITABLE | A BLINKING BAR WILL APPEAR WHEN EDITABLE -->

<p contenteditable="true">This is an editable paragraph.</p>