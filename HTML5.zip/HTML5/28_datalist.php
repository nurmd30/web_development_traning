<html>
<body>
	<form>
		<input list="division">

		<datalist id="division">
			<option value="Dhaka">
			<option value="Khulna">
			<option value="Rajshahi">
			<option value="Chittagong">
			<option value="Sylhet">
			<option value="Rangpur">
			<option value="Barisal">
		</datalist>
	</form>
</body>
</html>