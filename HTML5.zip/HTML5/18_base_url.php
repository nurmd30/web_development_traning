<!DOCTYPE html>
<html>
<head>
	<base href="http://nirjhor.net/" target="_blank">
</head>
<body>
	<a href="wp-content/uploads/2013/03/cropped-DSC030.jpg">
		<img src="wp-content/uploads/2013/03/cropped-DSC030.jpg" />
	</a>
</body>
</html>
