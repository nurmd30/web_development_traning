<!DOCTYPE html>
<html>
<body>

<form>
 <fieldset>
  <legend>Personal Information:</legend>
  Name: <input type="text"><br>
  Email: <input type="text"><br>
  Date of Birth: <input type="text">
 </fieldset>
</form>

</body>
</html>
