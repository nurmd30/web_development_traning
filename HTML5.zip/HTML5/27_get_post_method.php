<form action="" method="get" >

  First Name: <input type="text" name="first_name"><br>
  
  Last Name: <input type="text" name="last_name"><br>
  
  <input type="hidden" name="name_title" value="Dr. "><br>
  
  <input type="submit" value="Submit"><br>
  
</form>