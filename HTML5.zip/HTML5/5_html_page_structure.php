<!DOCTYPE html>
<html>

	<head>
		<!-- Your CSS and JAVASCRIPT codes will be Here -->
	</head>

	<body>
		<main>
		
			<header id="page_top">
				NIRJHOR.NET
			</header>
			
			<div id="page_inside">
				<article id="article1">
					<h3>
						Home Page
					</h3>
					<cite>Welcome</cite>
					<p>
						Dear Visitor, Welcome to my Website. <br />Thank you for visiting it!<br />
						Here you will get my Profile and Portfolio.<br /><br />
						<span>Nirjhor Anjum</span><br />
					</p>
					<aside>Note: To visit the Family Profile of Nirjhor Anjum go to www.family.com/anjum</aside><br />
				</article>
			</div>
			
			<section>
				<address>
					<abbr title="Nirjhor Network">NN</abbr> Inc.<br />
					55 Falmer Road, London<br />
					United Kingdom
				</address>
			</section>
			
			<footer id="page_tail">
				<details>
				  <summary>Copyright 1999-2014.</summary>
				  <p> - by Nirjhor Network Incorporate</p>
				  <p> - All content and graphics on this web site are the property of the company NN Inc.</p>
				</details>
			</footer>
			
		</main>
	</body>
	
</html>

