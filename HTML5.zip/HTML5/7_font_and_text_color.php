<html>

<body>

	<font size="5" color="red">This is Red text!</font>

	<font size="12" color="blue">This is Blue text!</font>

	<font face="Verdana" color="green">This is Green Verdana text!</font>

</body>

</html>