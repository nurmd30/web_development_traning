<!DOCTYPE html>
<html>
<body>

<img src="clickbutton.jpg" width="600" height="500" alt="Button" usemap="#button" />

<map name="button">
  <area shape="rect" coords="165,140,430,270" alt="Button" href="index.php">
</map>

</body>
</html>
