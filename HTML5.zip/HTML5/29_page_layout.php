<!DOCTYPE HTML>
<html>
<head>
	<title>Nirjhor.Net</title>
</head>

<body style="margin: 0px; padding: 0px; font-family: Trebuchet MS">
<table width="100%" style="height: 100%;" cellpadding="10" cellspacing="0" border="0">
	<tr>
		<!-- ============ HEADER SECTION ============== -->
		<td colspan="3" style="height: 100px;" bgcolor="#777d6a"><h1>Nirjhor.Net</h1></td></tr>
		<!-- ============ NAVIGATION BAR SECTION ============== -->
	<tr>
		<td colspan="3" valign="middle" height="30" bgcolor="#a9ae9f"><a href="#">Home</a></td></tr>
	<tr>
		<!-- ============ LEFT COLUMN (MENU) ============== -->
		<td width="20%" valign="top" bgcolor="#999f8e">
			<a href="#">Home</a><br>
			<a href="#">About Me</a><br>
			<a href="#">Photo Gallery</a><br>
			<a href="#">Video Gallery</a><br>
			<a href="#">Contact Me</a>
		</td>
		<!-- ============ MIDDLE COLUMN (CONTENT) ============== -->
		<td width="55%" valign="top" bgcolor="#d2d8c7">
			<h2>Welcome</h2>
			Welcome to my Website! <br>
			<br>
			Feel free to contact me anytime<br>
			<br>
		</td>
		<td width="25%" valign="top" bgcolor="#999f8e">&nbsp;</td>
	</tr>
	<!-- ============ FOOTER SECTION ============== -->
	<tr>
		<td colspan="3" align="center" height="20" bgcolor="#777d6a">Copyright &copy;</td>
	</tr>
</table>
</body>

<html>