<html>

<body>

<nav>
	<a href="html/">HTML</a> | <a href="php/">PHP</a> | <a href="mysql/">MySQL</a>
</nav>

</body>
</html>