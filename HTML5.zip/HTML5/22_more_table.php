<!DOCTYPE html>
<html>
<head>

</head>
<body>

<table style="border-collapse:collapse;border-color:gray;width:100%;text-align:center;" border="1">
	<colgroup>
		<col span="1" style="background-color:lightgreen">
		<col span="1" style="background-color:lightblue">
		<col span="1" style="background-color:lightblue">
	</colgroup>
	<tr>
		<th>NAME</th>
		<th>SALARY</th>
		<th>OFFICE</th>
	</tr>
	<tr>
		<td>Nirjhor Anjum</td>
		<td>500000</td>
		<td>Eskaton Road</td>
	</tr>
	<tr>
		<td>Dr. Ishak Anjum</td>
		<td>900000</td>
		<td>Panthapath</td>
	</tr>
</table>

</body>
</html>